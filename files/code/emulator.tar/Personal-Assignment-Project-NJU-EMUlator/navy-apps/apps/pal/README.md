# PAL

This is a fork of SDLPAL(https://github.com/sdlpal/sdlpal).
It is ported to Navy-apps.
