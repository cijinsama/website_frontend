#include <sdl-file.h>

SDL_RWops* SDL_RWFromFile(const char *filename, const char *mode) {
  return NULL;
}

SDL_RWops* SDL_RWFromMem(void *mem, int size) {
  return NULL;
}
