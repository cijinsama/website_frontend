#include <stdint.h>
#include <stdio.h>

int main() {
	while(1){
		printf("This is dummy running\n");
	}
  return 0;
}
